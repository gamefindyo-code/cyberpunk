from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
import csv
import datetime as dt
import json
import os
import random
import shutil
import sqlite3
import sys

APP_NAME = "NC R9 Production Manager"
DB_FILENAME = "manager.db"


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def resource_root() -> Path:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent


def default_user_data_dir() -> Path:
    if sys.platform.startswith("win"):
        base = Path(os.environ.get("LOCALAPPDATA") or Path.home())
        return base / "NC_R9_Production_Manager"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "NC_R9_Production_Manager"
    return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "NC_R9_Production_Manager"


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def weighted_choice(rows: Sequence[Dict[str, Any]], rng: random.Random, key: str = "weight") -> str:
    if not rows:
        raise ValueError("Cannot choose from empty list")
    weights = [max(0.0, float(x.get(key, 1) or 1)) for x in rows]
    if not any(weights):
        weights = [1.0] * len(rows)
    return rng.choices([x["id"] for x in rows], weights=weights, k=1)[0]


def weighted_mapping_choice(weights: Dict[str, Any], rng: random.Random) -> str:
    rows = [{"id": k, "weight": v} for k, v in weights.items()]
    return weighted_choice(rows, rng)


def human_subject_mode(mode: Optional[str]) -> bool:
    """Whether the main cover identity is face-bearing enough to justify a Face ID history lock."""
    if not mode:
        return True
    face_bearing = {
        "fictional_human", "vehicle_plus_human", "vehicle_plus_participant",
        "duo_or_special", "duo", "conceptual_portrait", "duo_or_group", "duo_or_band"
    }
    return mode in face_bearing


def vehicle_subject_mode(mode: Optional[str]) -> bool:
    return bool(mode and ("vehicle" in mode or "car" in mode or "motorcycle" in mode))


@dataclass
class CandidateInput:
    publication: str
    year: str
    presentation: str
    subject_mode: str
    face_id: str
    canon_star_id: str
    primary_vehicle_id: str
    issue_mode_id: str
    layout_template_id: str
    environment_family_id: str
    crop_family_id: str
    user_note: str = ""


class Catalog:
    def __init__(self, root: Optional[Path] = None):
        root = root or resource_root()
        self.path = root / "data" / "catalog.json"
        self.data = load_json(self.path)
        self.publications: List[str] = self.data["publications"]
        self.faces = self.data["faces"]
        self.face_ids = [x["id"] for x in self.faces]
        self.canon_stars = self.data["canon_stars"]
        self.canon_by_id = {x["id"]: x for x in self.canon_stars}
        self.vehicles = self.data["vehicles"]
        self.vehicle_ids = [x["id"] for x in self.vehicles]
        self.environment_families = self.data["environment_families"]
        self.crop_families = self.data["crop_families"]
        self.env_ids = [x["id"] for x in self.environment_families]
        self.crop_ids = [x["id"] for x in self.crop_families]

    def issue_modes(self, publication: str) -> List[Dict[str, Any]]:
        return list(self.data["issue_modes"].get(publication, []))

    def layouts(self, publication: str) -> List[Dict[str, Any]]:
        return list(self.data["layout_templates"].get(publication, []))

    def subject_modes(self, publication: str) -> List[Dict[str, Any]]:
        return list(self.data["subject_modes"].get(publication, []))

    def presentation_weights(self, publication: str) -> Dict[str, Any]:
        return dict(self.data["presentation_weights"].get(publication, {"woman": 1, "man": 1}))

    def canon_for_publication(self, publication: str) -> List[Dict[str, Any]]:
        preferred = [x for x in self.canon_stars if publication in x.get("magazine_affinity", [])]
        return preferred or list(self.canon_stars)

    def env_pool(self, publication: str) -> List[str]:
        return list(self.data["environment_preferences"].get(publication, self.env_ids))

    def crop_pool(self, publication: str, subject_mode: Optional[str]) -> List[str]:
        if vehicle_subject_mode(subject_mode):
            pool = ["vehicle_hero", "vehicle_plus_human"]
            if subject_mode == "vehicle_only":
                return ["vehicle_hero"]
            return pool
        return list(self.data["crop_preferences"].get(publication, self.crop_ids))

    def is_automotive(self, publication: str) -> bool:
        return publication in set(self.data.get("automotive_publications", []))


class ManagerDB:
    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path or (default_user_data_dir() / DB_FILENAME))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path)
        self.conn.row_factory = sqlite3.Row
        self.init_schema()

    def close(self) -> None:
        self.conn.close()

    def init_schema(self) -> None:
        self.conn.executescript(
            """
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS candidates (
                candidate_id TEXT PRIMARY KEY,
                seq INTEGER NOT NULL UNIQUE,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                accepted_at TEXT,
                rejected_at TEXT,
                status TEXT NOT NULL CHECK(status IN ('PENDING','ACCEPTED','REJECTED')),
                publication TEXT NOT NULL,
                year INTEGER NOT NULL,
                presentation TEXT,
                subject_mode TEXT,
                face_id TEXT,
                canon_star_id TEXT,
                primary_vehicle_id TEXT,
                issue_mode_id TEXT,
                layout_template_id TEXT,
                environment_family_id TEXT,
                crop_family_id TEXT,
                user_note TEXT,
                selection_json TEXT NOT NULL,
                request_text TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_candidates_status ON candidates(status);
            CREATE INDEX IF NOT EXISTS idx_candidates_pub ON candidates(publication);
            CREATE INDEX IF NOT EXISTS idx_candidates_face ON candidates(face_id);
            CREATE INDEX IF NOT EXISTS idx_candidates_vehicle ON candidates(primary_vehicle_id);
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            """
        )
        self.conn.commit()

    def get_setting(self, key: str, default: Any = None) -> Any:
        row = self.conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        if not row:
            return default
        try:
            return json.loads(row["value"])
        except Exception:
            return row["value"]

    def set_setting(self, key: str, value: Any) -> None:
        self.conn.execute(
            "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(value, ensure_ascii=False)),
        )
        self.conn.commit()

    def next_candidate_id(self) -> Tuple[int, str]:
        row = self.conn.execute("SELECT COALESCE(MAX(seq),0)+1 AS n FROM candidates").fetchone()
        n = int(row["n"])
        return n, f"CAND-{n:04d}"

    def insert_candidate(self, record: Dict[str, Any]) -> None:
        cols = [
            "candidate_id","seq","created_at","updated_at","accepted_at","rejected_at","status",
            "publication","year","presentation","subject_mode","face_id","canon_star_id","primary_vehicle_id",
            "issue_mode_id","layout_template_id","environment_family_id","crop_family_id","user_note",
            "selection_json","request_text"
        ]
        values = [record.get(c) for c in cols]
        self.conn.execute(
            f"INSERT INTO candidates ({','.join(cols)}) VALUES ({','.join('?' for _ in cols)})",
            values,
        )
        self.conn.commit()

    def update_status(self, candidate_id: str, status: str) -> None:
        if status not in {"PENDING", "ACCEPTED", "REJECTED"}:
            raise ValueError(status)
        now = utc_now()
        accepted = now if status == "ACCEPTED" else None
        rejected = now if status == "REJECTED" else None
        self.conn.execute(
            "UPDATE candidates SET status=?, updated_at=?, accepted_at=?, rejected_at=? WHERE candidate_id=?",
            (status, now, accepted, rejected, candidate_id),
        )
        self.conn.commit()

    def get_candidate(self, candidate_id: str) -> Optional[Dict[str, Any]]:
        row = self.conn.execute("SELECT * FROM candidates WHERE candidate_id=?", (candidate_id,)).fetchone()
        return dict(row) if row else None

    def list_candidates(self, status: Optional[str] = None, publication: Optional[str] = None) -> List[Dict[str, Any]]:
        q = "SELECT * FROM candidates WHERE 1=1"
        args: List[Any] = []
        if status and status != "ALL":
            q += " AND status=?"; args.append(status)
        if publication and publication != "ALL":
            q += " AND publication=?"; args.append(publication)
        q += " ORDER BY seq DESC"
        return [dict(x) for x in self.conn.execute(q, args).fetchall()]

    def accepted_recent(self, limit: int, publication: Optional[str] = None, nonempty_field: Optional[str] = None) -> List[Dict[str, Any]]:
        q = "SELECT * FROM candidates WHERE status='ACCEPTED'"
        args: List[Any] = []
        if publication:
            q += " AND publication=?"; args.append(publication)
        if nonempty_field:
            if nonempty_field not in {
                "face_id","canon_star_id","primary_vehicle_id","issue_mode_id","layout_template_id",
                "environment_family_id","crop_family_id","subject_mode"
            }:
                raise ValueError("Unsafe field")
            q += f" AND {nonempty_field} IS NOT NULL AND {nonempty_field}<>'' AND {nonempty_field}<>'NONE'"
        q += " ORDER BY seq DESC LIMIT ?"; args.append(int(limit))
        return [dict(x) for x in self.conn.execute(q, args).fetchall()]

    def pending(self, exclude_candidate: Optional[str] = None) -> List[Dict[str, Any]]:
        q = "SELECT * FROM candidates WHERE status='PENDING'"
        args: List[Any] = []
        if exclude_candidate:
            q += " AND candidate_id<>?"; args.append(exclude_candidate)
        q += " ORDER BY seq DESC"
        return [dict(x) for x in self.conn.execute(q, args).fetchall()]

    def backup(self, output: Path) -> None:
        output = Path(output)
        output.parent.mkdir(parents=True, exist_ok=True)
        dest = sqlite3.connect(output)
        try:
            self.conn.backup(dest)
        finally:
            dest.close()

    def export_accepted_csv(self, output: Path) -> None:
        rows = self.list_candidates(status="ACCEPTED")
        fields = [
            "candidate_id","accepted_at","publication","year","subject_mode","face_id","canon_star_id",
            "primary_vehicle_id","issue_mode_id","layout_template_id","environment_family_id","crop_family_id"
        ]
        with Path(output).open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            for r in reversed(rows):
                w.writerow({k: r.get(k) for k in fields})


DEFAULT_SETTINGS = {
    "history.face_id.window": 12,
    "history.canon_star_id.window": 18,
    "history.primary_vehicle_id.window": 6,
    "history.subject_mode.window": 2,
    "history.issue_mode_id.window": 2,
    "history.layout_template_id.window": 3,
    "history.environment_family_id.window": 3,
    "history.crop_family_id.window": 2,
    "pending_guard.face_id": True,
    "pending_guard.canon_star_id": True,
    "pending_guard.primary_vehicle_id": True,
    "pending_guard.layout_template_id": True,
}


class CandidateEngine:
    HARD_FIELDS = {"face_id", "canon_star_id", "primary_vehicle_id"}
    SOFT_FIELDS = {"subject_mode", "issue_mode_id", "layout_template_id", "environment_family_id", "crop_family_id"}

    def __init__(self, db: ManagerDB, catalog: Catalog, rng: Optional[random.Random] = None):
        self.db = db
        self.catalog = catalog
        self.rng = rng or random.Random()
        for k, v in DEFAULT_SETTINGS.items():
            if self.db.get_setting(k, None) is None:
                self.db.set_setting(k, v)

    def setting(self, key: str) -> Any:
        return self.db.get_setting(key, DEFAULT_SETTINGS.get(key))

    def _recent_values(self, field: str, publication: Optional[str], limit: int, specialized_scope: Optional[str] = None) -> List[str]:
        if specialized_scope == "global_vehicle_led":
            rows = self.db.accepted_recent(limit, nonempty_field="primary_vehicle_id")
        else:
            rows = self.db.accepted_recent(limit, publication=publication)
        return [r.get(field) for r in rows if r.get(field) not in (None, "", "NONE")]

    def _pending_values(self, field: str) -> List[str]:
        if not self.setting(f"pending_guard.{field}"):
            return []
        return [r.get(field) for r in self.db.pending() if r.get(field) not in (None, "", "NONE")]

    def _pick_avoiding(self, pool: Sequence[str], avoid: Iterable[str], random_mode: bool = False) -> str:
        pool = [x for x in pool if x not in (None, "", "NONE")]
        if not pool:
            return "NONE"
        avoid_set = set(avoid)
        fresh = [x for x in pool if x not in avoid_set]
        choices = fresh or list(pool)
        return self.rng.choice(choices)

    def _resolve_year(self, selection: str) -> int:
        if selection in {"AUTO", "RANDOM", ""}:
            if selection == "RANDOM":
                return self.rng.choice(self.catalog.data["years"])
            return self.rng.choices([2075,2076,2077], weights=[25,35,40], k=1)[0]
        return int(selection)

    def _resolve_presentation(self, publication: str, selection: str) -> str:
        if selection == "RANDOM":
            return self.rng.choice(self.catalog.data["presentations"])
        if selection in {"AUTO", ""}:
            return weighted_mapping_choice(self.catalog.presentation_weights(publication), self.rng)
        return selection

    def _resolve_subject_mode(self, publication: str, selection: str) -> str:
        rows = self.catalog.subject_modes(publication)
        ids = [x["id"] for x in rows]
        if selection not in {"AUTO", "RANDOM", ""}:
            return selection
        window = int(self.setting("history.subject_mode.window"))
        avoid = set(self._recent_values("subject_mode", publication, window))
        available = [x for x in rows if x["id"] not in avoid] or rows
        if selection == "RANDOM":
            return self.rng.choice([x["id"] for x in available])
        return weighted_choice(available, self.rng)

    def _resolve_canon(self, publication: str, selection: str) -> str:
        if selection in {"NONE", "", None}:
            return "NONE"
        if selection not in {"AUTO", "RANDOM"}:
            return selection
        rows = self.catalog.canon_for_publication(publication)
        pool = [x["id"] for x in rows]
        window = int(self.setting("history.canon_star_id.window"))
        avoid = self._recent_values("canon_star_id", None, window) + self._pending_values("canon_star_id")
        return self._pick_avoiding(pool, avoid, selection == "RANDOM")

    def _resolve_vehicle(self, publication: str, subject_mode: str, selection: str) -> str:
        needs_vehicle = vehicle_subject_mode(subject_mode) or self.catalog.is_automotive(publication)
        if selection in {"NONE", "", None} and not needs_vehicle:
            return "NONE"
        if selection not in {"AUTO", "RANDOM", "NONE", "", None}:
            return selection
        # Vehicle-led modes cannot leave the primary vehicle unknown, otherwise history cannot track it.
        if not needs_vehicle and selection == "NONE":
            return "NONE"
        pool = list(self.catalog.vehicle_ids)
        window = int(self.setting("history.primary_vehicle_id.window"))
        avoid = self._recent_values("primary_vehicle_id", None, window, specialized_scope="global_vehicle_led") + self._pending_values("primary_vehicle_id")
        return self._pick_avoiding(pool, avoid, selection == "RANDOM")

    def _resolve_face(self, subject_mode: str, canon_star_id: str, selection: str) -> str:
        if canon_star_id != "NONE" or not human_subject_mode(subject_mode):
            return "NONE"
        if selection not in {"AUTO", "RANDOM", "NONE", "", None}:
            return selection
        if selection == "NONE":
            # Human-led fictional cover without a Face ID would defeat identity history; resolve it.
            selection = "AUTO"
        window = int(self.setting("history.face_id.window"))
        avoid = self._recent_values("face_id", None, window) + self._pending_values("face_id")
        return self._pick_avoiding(self.catalog.face_ids, avoid, selection == "RANDOM")

    def _resolve_issue_mode(self, publication: str, selection: str) -> str:
        rows = self.catalog.issue_modes(publication)
        if selection not in {"AUTO", "RANDOM", ""}:
            return selection
        window = int(self.setting("history.issue_mode_id.window"))
        avoid = set(self._recent_values("issue_mode_id", publication, window))
        available = [x for x in rows if x["id"] not in avoid] or rows
        if selection == "RANDOM":
            return self.rng.choice([x["id"] for x in available])
        return weighted_choice(available, self.rng)

    def _resolve_layout(self, publication: str, issue_mode: str, subject_mode: str, selection: str) -> str:
        rows = self.catalog.layouts(publication)
        if selection not in {"AUTO", "RANDOM", ""}:
            return selection
        filtered = []
        for row in rows:
            issue_ok = not row.get("issue_modes") or issue_mode in row.get("issue_modes", [])
            subject_ok = not row.get("subject_modes") or subject_mode in row.get("subject_modes", [])
            if issue_ok and subject_ok:
                filtered.append(row)
        if not filtered:
            filtered = rows
        window = int(self.setting("history.layout_template_id.window"))
        avoid = set(self._recent_values("layout_template_id", publication, window) + self._pending_values("layout_template_id"))
        available = [x for x in filtered if x["id"] not in avoid] or filtered
        if selection == "RANDOM":
            return self.rng.choice([x["id"] for x in available])
        return weighted_choice(available, self.rng)

    def _resolve_environment(self, publication: str, selection: str) -> str:
        if selection not in {"AUTO", "RANDOM", ""}:
            return selection
        pool = self.catalog.env_pool(publication)
        window = int(self.setting("history.environment_family_id.window"))
        avoid = self._recent_values("environment_family_id", None, window)
        return self._pick_avoiding(pool, avoid, selection == "RANDOM")

    def _resolve_crop(self, publication: str, subject_mode: str, selection: str) -> str:
        if selection not in {"AUTO", "RANDOM", ""}:
            return selection
        pool = self.catalog.crop_pool(publication, subject_mode)
        window = int(self.setting("history.crop_family_id.window"))
        avoid = self._recent_values("crop_family_id", None, window)
        return self._pick_avoiding(pool, avoid, selection == "RANDOM")

    def explicit_warnings(self, inp: CandidateInput) -> List[Dict[str, Any]]:
        warnings: List[Dict[str, Any]] = []
        checks = [
            ("face_id", inp.face_id, None, int(self.setting("history.face_id.window")), "HARD"),
            ("canon_star_id", inp.canon_star_id, None, int(self.setting("history.canon_star_id.window")), "HARD"),
            ("primary_vehicle_id", inp.primary_vehicle_id, None, int(self.setting("history.primary_vehicle_id.window")), "HARD"),
            ("subject_mode", inp.subject_mode, inp.publication, int(self.setting("history.subject_mode.window")), "SOFT"),
            ("issue_mode_id", inp.issue_mode_id, inp.publication, int(self.setting("history.issue_mode_id.window")), "SOFT"),
            ("layout_template_id", inp.layout_template_id, inp.publication, int(self.setting("history.layout_template_id.window")), "SOFT"),
            ("environment_family_id", inp.environment_family_id, None, int(self.setting("history.environment_family_id.window")), "SOFT"),
            ("crop_family_id", inp.crop_family_id, None, int(self.setting("history.crop_family_id.window")), "SOFT"),
        ]
        for field, value, publication, window, severity in checks:
            if value in {None, "", "AUTO", "RANDOM", "NONE"}:
                continue
            recent = self.db.accepted_recent(window, publication=publication, nonempty_field=field)
            for distance, row in enumerate(recent, start=1):
                if row.get(field) == value:
                    warnings.append({
                        "severity": severity,
                        "field": field,
                        "value": value,
                        "message": f"{value} использован {distance} принят(ых) обложек назад" + (f" в {publication}" if publication else ""),
                        "candidate_id": row.get("candidate_id"),
                    })
                    break
            if self.setting(f"pending_guard.{field}"):
                for row in self.db.pending():
                    if row.get(field) == value:
                        warnings.append({
                            "severity": "PENDING",
                            "field": field,
                            "value": value,
                            "message": f"{value} уже используется в текущем PENDING {row['candidate_id']}",
                            "candidate_id": row.get("candidate_id"),
                        })
                        break
        return warnings

    def resolve(self, inp: CandidateInput) -> Dict[str, Any]:
        pub = inp.publication
        if pub not in self.catalog.publications:
            raise ValueError(f"Unknown publication: {pub}")
        year = self._resolve_year(inp.year)
        presentation = self._resolve_presentation(pub, inp.presentation)
        subject_mode = self._resolve_subject_mode(pub, inp.subject_mode)
        canon = self._resolve_canon(pub, inp.canon_star_id)
        if canon != "NONE" and inp.face_id not in {"AUTO", "RANDOM", "NONE", ""}:
            raise ValueError("Нельзя одновременно зафиксировать Canon Star и fictional Face ID.")
        face = self._resolve_face(subject_mode, canon, inp.face_id)
        vehicle = self._resolve_vehicle(pub, subject_mode, inp.primary_vehicle_id)
        issue = self._resolve_issue_mode(pub, inp.issue_mode_id)
        layout = self._resolve_layout(pub, issue, subject_mode, inp.layout_template_id)
        env = self._resolve_environment(pub, inp.environment_family_id)
        crop = self._resolve_crop(pub, subject_mode, inp.crop_family_id)
        return {
            "publication": pub,
            "year": year,
            "presentation": presentation,
            "subject_mode": subject_mode,
            "face_id": face,
            "canon_star_id": canon,
            "primary_vehicle_id": vehicle,
            "issue_mode_id": issue,
            "layout_template_id": layout,
            "environment_family_id": env,
            "crop_family_id": crop,
            "user_note": (inp.user_note or "").strip(),
        }

    def request_text(self, candidate_id: str, r: Dict[str, Any]) -> str:
        note = r.get("user_note") or "NONE"
        return f"""NC R9 PRODUCTION REQUEST
Candidate ID: {candidate_id}

Publication: {r['publication']}
Year: {r['year']}
Presentation: {r['presentation']}
Subject Mode: {r['subject_mode']}

Face ID: {r['face_id']}
Canon Star ID: {r['canon_star_id']}
Primary Vehicle ID: {r['primary_vehicle_id']}

Issue Mode ID: {r['issue_mode_id']}
Layout Template ID: {r['layout_template_id']}
Environment Family ID: {r['environment_family_id']}
Crop Family ID: {r['crop_family_id']}

ALL NON-CRITICAL PARAMETERS: AUTO

USER NOTE:
{note}

INSTRUCTIONS:
- Open and follow NC Magazine Masterpack v4.0 R9 LEAN PRODUCTION.
- Preserve every explicit critical ID/value above.
- Resolve all non-critical parameters through normal R9 Publication DNA, Issue Intelligence, layout and photo-plate pipeline.
- Run the real R9 production compiler; do not mentally simulate compilation.
- Map manager-level Environment Family and Crop Family to the closest valid R9 photographic choices while preserving their semantic category.
- Do not silently replace locked critical values because of history or your own preferences.
- Produce the normal R9 text-free photo-plate generation workflow first; typography remains a separate deterministic stage.
""".strip()

    def create_candidate(self, inp: CandidateInput) -> Dict[str, Any]:
        seq, cid = self.db.next_candidate_id()
        resolved = self.resolve(inp)
        request = self.request_text(cid, resolved)
        now = utc_now()
        rec = {
            "candidate_id": cid,
            "seq": seq,
            "created_at": now,
            "updated_at": now,
            "accepted_at": None,
            "rejected_at": None,
            "status": "PENDING",
            **resolved,
            "selection_json": json.dumps(asdict(inp), ensure_ascii=False),
            "request_text": request,
        }
        self.db.insert_candidate(rec)
        return self.db.get_candidate(cid) or rec

    def duplicate_as_new(self, candidate_id: str) -> Dict[str, Any]:
        row = self.db.get_candidate(candidate_id)
        if not row:
            raise ValueError("Candidate not found")
        inp = CandidateInput(
            publication=row["publication"], year=str(row["year"]), presentation=row.get("presentation") or "AUTO",
            subject_mode=row.get("subject_mode") or "AUTO", face_id=row.get("face_id") or "NONE",
            canon_star_id=row.get("canon_star_id") or "NONE", primary_vehicle_id=row.get("primary_vehicle_id") or "NONE",
            issue_mode_id=row.get("issue_mode_id") or "AUTO", layout_template_id=row.get("layout_template_id") or "AUTO",
            environment_family_id=row.get("environment_family_id") or "AUTO", crop_family_id=row.get("crop_family_id") or "AUTO",
            user_note=row.get("user_note") or ""
        )
        return self.create_candidate(inp)


def display_value(value: Optional[str]) -> str:
    return value if value not in (None, "") else "NONE"
