# NC R9 Production Manager — UI Specification v1

## 1. Общая идея

Приложение не заменяет R9 и не строит полный image prompt.

Его функции:
- выбрать только критические production-параметры;
- создать Candidate ID;
- проверить critical history;
- сохранить R9 Production Request;
- вести `PENDING / ACCEPTED / REJECTED`;
- выдавать готовый короткий запрос для ChatGPT + R9.

Вся одежда, причёска, макияж, поза, свет, cyberware details и прочие некритичные параметры остаются внутри R9 как `AUTO`.

---

## 2. Главное окно — Candidate Builder

Экран делится на две колонки.

### Левая колонка — выбор параметров

#### ISSUE
- Publication
- Year
- Presentation
- Subject Mode

#### IDENTITY / STAR
- Face ID
- Canon Star
- Primary Vehicle

#### EDITORIAL / COMPOSITION
- Issue Mode
- Layout Template
- Environment Family
- Crop Family

#### OPTIONAL NOTES
Многострочное поле для комментария вроде:

`Более дерзкий летний выпуск, без ночного неона, дневной resort mood.`

Это поле не участвует в history.

### Правая колонка — Live Summary

Показывает:
- будущий Candidate ID;
- журнал / год;
- выбранные critical parameters;
- HARD / SOFT history warnings;
- конфликты с текущими PENDING-кандидатами;
- preview R9 Request.

Внизу:
- `RANDOMIZE AUTO/RANDOM`
- `RESET TO AUTO`
- `CREATE CANDIDATE`

---

## 3. Режимы полей

У каждого критического поля есть режим.

**AUTO**  
Приложение выбирает допустимое значение с учётом history и контекста журнала.

**RANDOM**  
Случайный допустимый вариант с соблюдением hard no-repeat.

**EXACT**  
Конкретное значение пользователя. Считается LOCKED автоматически.

Для Canon Star и Vehicle дополнительно:

**NONE**

---

## 4. History warnings

### HARD

Используются для:
- Face ID;
- Canon Star;
- Primary Vehicle.

Пример:

`⚠ F074 был использован 3 принятые обложки назад.`

Если значение пришло из AUTO/RANDOM — оно должно быть заменено автоматически.

Если пользователь сам выбрал F074 — показываются кнопки:

`USE ANYWAY`  
`CHANGE TO AUTO`

Приложение никогда не меняет explicit selection молча.

### SOFT

Используются для:
- Subject Mode;
- Issue Mode;
- Layout Template;
- Environment Family;
- Crop Family.

Показывается небольшой warning badge, но Candidate можно создать сразу.

---

## 5. Pending Batch Guard

Отдельная временная проверка между ещё не принятыми кандидатами.

По умолчанию проверяет:
- Face ID;
- Canon Star;
- Primary Vehicle;
- Layout Template.

Пример:

`PENDING CONFLICT: F052 уже используется в CAND-0018.`

Это не permanent history.

После Reject этот конфликт исчезает.
После Accept кандидат начинает участвовать уже в permanent history.

---

## 6. После CREATE CANDIDATE

Открывается Candidate Detail.

Пример:

```text
CAND-0042
Status: PENDING

PLAYBYTE / 2077
Woman
Face ID: F074
Canon Star: NONE
Vehicle: NONE
Issue Mode: dating_relationships
Layout: classic_newsstand
Environment: resort
Crop: medium_full
```

Ниже отображается полный **R9 Production Request**.

Кнопки:

`COPY R9 REQUEST`

`ACCEPT`

`REJECT`

`DUPLICATE AS NEW`

`OPEN RAW RECORD`

---

## 7. Что копируется в ChatGPT

Приложение формирует запрос такого вида:

```text
NC R9 PRODUCTION REQUEST
Candidate ID: CAND-0042

Publication: PLAYBYTE
Year: 2077
Presentation: woman
Subject Mode: fictional_human

Face ID: F074
Canon Star: NONE
Primary Vehicle: NONE

Issue Mode: dating_relationships
Layout Template: classic_newsstand
Environment Family: resort
Crop Family: medium_full

ALL NON-CRITICAL PARAMETERS: AUTO

USER NOTE:
Более дерзкий летний выпуск, дневной resort mood.

INSTRUCTIONS:
Open and follow R9 LEAN PRODUCTION.
Preserve every explicit ID/value above.
Resolve all non-critical parameters through normal R9 Publication DNA,
Issue Intelligence, layout and photo-plate pipeline.
Run the real R9 compiler.
Do not replace locked critical values because of your own preferences.
```

---

## 8. Candidates screen

Отдельная таблица всех созданных кандидатов.

Колонки:
- Candidate ID
- Created
- Publication
- Face ID
- Canon
- Vehicle
- Issue Mode
- Layout
- Status

Status:
- PENDING
- ACCEPTED
- REJECTED

Фильтры:
- publication;
- status;
- year;
- Face ID;
- vehicle.

Двойной клик открывает Candidate Detail.

---

## 9. Accepted History screen

Показывает только ACCEPTED.

Хранит только критические параметры.

Не хранит одежду, волосы, макияж, lighting и прочие неважные для повторений детали.

Можно:
- фильтровать;
- экспортировать history;
- делать backup;
- смотреть, когда последний раз использовался Face ID / vehicle / layout.

---

## 10. Settings

### NO-REPEAT RULES

Пользователь может изменить окна, например:

```text
Face ID          12
Canon Star       18
Primary Vehicle   6
Issue Mode         2
Layout             3
Environment        3
Crop               2
```

И включать/выключать конкретные rules.

### PENDING BATCH GUARD

Отдельные переключатели:
- Face ID
- Canon Star
- Vehicle
- Layout

### BACKUP

- `BACKUP DATABASE`
- `RESTORE DATABASE`
- `EXPORT ACCEPTED HISTORY`

---

## 11. Рекомендуемый layout окна

```text
┌──────────────────────────────────────────────────────────────────────┐
│ NC R9 PRODUCTION MANAGER                             [History] [⚙]  │
├────────────────────────────────────┬─────────────────────────────────┤
│ CANDIDATE BUILDER                  │ LIVE SUMMARY                    │
│                                    │                                 │
│ ISSUE                              │ Next: CAND-0042                 │
│ Publication   [ PLAYBYTE ▼ ]       │ PLAYBYTE / 2077                 │
│ Year          [ 2077 ▼ ]           │ Woman                           │
│ Presentation  [ AUTO ▼ ]           │                                 │
│ Subject Mode  [ AUTO ▼ ]           │ Face: F074                      │
│                                    │ Issue: dating_relationships     │
│ IDENTITY / STAR                    │ Layout: classic_newsstand       │
│ Face ID       [ AUTO ▼ ]           │ Environment: resort             │
│ Canon Star    [ NONE ▼ ]           │ Crop: medium_full               │
│ Vehicle       [ NONE ▼ ]           │                                 │
│                                    │ HISTORY                         │
│ EDITORIAL                          │ ✓ No hard conflicts             │
│ Issue Mode    [ AUTO ▼ ]           │ ⚠ Layout used 2 issues ago      │
│ Layout        [ AUTO ▼ ]           │                                 │
│ Environment   [ AUTO ▼ ]           │ REQUEST PREVIEW                 │
│ Crop          [ AUTO ▼ ]           │ NC R9 PRODUCTION REQUEST...     │
│                                    │                                 │
│ NOTES                              │                                 │
│ [                              ]   │                                 │
│ [                              ]   │                                 │
│                                    │                                 │
│ [ RANDOMIZE ] [ RESET ]            │                                 │
│ [       CREATE CANDIDATE       ]   │                                 │
└────────────────────────────────────┴─────────────────────────────────┘
```

---

## 12. Что сознательно НЕ будет в интерфейсе

Не добавляем dropdown'ы для:
- конкретной одежды;
- причёски;
- цвета волос;
- makeup;
- материала;
- обуви;
- позы;
- lighting;
- cyberware details;
- gaze;
- аксессуаров;
- minor props.

Это задача R9.

Если пользователь хочет что-то из этого явно указать, он пишет это в `Optional Notes`. Оно попадёт в R9 Request, но не станет history-critical параметром.

---

## 13. Минимальный первый релиз

Для первой рабочей версии достаточно четырёх экранов:

**Candidate Builder → Candidate Detail → Candidates → History**

Settings можно сделать минимальным.

Критерий готовности MVP:

пользователь способен создать 50 кандидатов, принять часть из них, отклонить остальные, закрыть приложение, открыть снова и продолжить работу без потери Candidate ID, request-текстов и accepted history.
