# NC R9 Manager — Critical History Specification v1

## Цель

Приложение **не генерирует image prompt** и не дублирует R9 compiler.

Его задачи только:

1. дать пользователю выбрать критические параметры;
2. создать `CAND-XXXX`;
3. сформировать короткий **R9 Production Request**;
4. хранить `PENDING / ACCEPTED / REJECTED`;
5. предотвращать только действительно важные визуальные повторы;
6. отдавать всё некритичное R9 как `AUTO`.

Ключевой принцип:

> **Сохранять параметр ≠ запрещать его повторять.**

Одежда, волосы, поза, свет и прочие детали могут повторяться свободно.

---

## 1. Поля интерфейса

| Поле | Участвует в no-repeat | Правило |
|---|---:|---|
| Publication | Нет | Обязательный выбор; задаёт набор допустимых Issue Modes и Layouts |
| Year | Нет | Хронология; повторение разрешено |
| Presentation | Нет | AUTO / RANDOM / конкретно; повторение разрешено |
| Subject Mode | Да, мягко | Не повторять автоматически в последних **2** выпусках того же журнала, если есть альтернатива |
| Face ID | **Да** | AUTO не использует Face ID из последних **12** принятых обложек глобально |
| Canon Star | **Да** | AUTO не использует того же canon cover star последние **18** принятых обложек |
| Primary Vehicle | **Да** | AUTO не использует ту же hero-машину/байк последние **6** vehicle-led обложек |
| Issue Mode | Да, мягко | Избегать последних **2** Issue Modes того же журнала |
| Layout Template | Да, мягко | Избегать последних **3** layout templates того же журнала |
| Environment Family | Да, мягко | Избегать последних **3** глобально |
| Crop Family | Да, мягко | Избегать последних **2** human-led обложек |

### HARD FOR AUTO

`Face ID`, `Canon Star`, `Primary Vehicle`.

Если поле стоит `AUTO/RANDOM`, приложение исключает недавние значения.

Если пользователь **сам выбрал** повторяющееся значение — приложение **не меняет его**, а только показывает предупреждение.

### SOFT

`Subject Mode`, `Issue Mode`, `Layout`, `Environment Family`, `Crop Family`.

AUTO старается выбрать другое значение, но это не абсолютный запрет.

---

## 2. Что НЕ участвует в no-repeat

Не контролируем историю для:

- одежды и конкретных предметов одежды;
- материала;
- обуви;
- причёски и цвета волос;
- макияжа / grooming;
- позы;
- gaze;
- emotion;
- lighting;
- cyberware details;
- аксессуаров;
- цвета машины;
- props;
- мелких деталей фона;
- конкретной формулировки headlines;
- print finish.

R9 имеет право повторять эти вещи столько, сколько это естественно для выпуска.

---

## 3. Candidate и History — разные сущности

### Candidate

При нажатии `CREATE CANDIDATE` приложение сразу сохраняет:

- Candidate ID;
- все выбранные критические параметры;
- сгенерированный R9 Request;
- status = `PENDING`.

Это нужно, чтобы через 20 обложек точно знать, какой request относился к какой картинке.

### Accepted History

В постоянный no-repeat history запись попадает **только после ACCEPT**.

`REJECTED` и `PENDING` не продвигают постоянную ротацию.

---

## 4. Pending Batch Guard

Есть отдельная временная защита, включённая по умолчанию:

**Avoid duplicates among current PENDING candidates.**

Она не является постоянной history.

Например если создано 10 ещё не принятых кандидатов, AUTO постарается не выдать им один и тот же:

- Face ID;
- Canon Star;
- Primary Vehicle;
- Layout Template.

Если пользователь намеренно фиксирует одно значение — оно разрешено.

---

## 5. Режим каждого поля

Для обычного поля:

- `AUTO` — выбрать разумно с учётом publication + history;
- `RANDOM` — случайное допустимое значение с учётом hard no-repeat;
- `EXACT` — конкретное значение пользователя.

Дополнительно для Canon/Vehicle:

- `NONE`.

В UI выбранное конкретное значение считается **LOCKED** автоматически.

---

## 6. Поведение при конфликте

### Пользователь выбрал F074, но F074 был 3 выпуска назад

Не менять F074.

Показывать:

`⚠ HARD HISTORY REPEAT: F074 used 3 accepted covers ago`

Кнопки:

`USE ANYWAY` / `CHANGE TO AUTO`

### AUTO выбрал повтор

Такого происходить не должно, пока есть допустимые варианты.

---

## 7. Минимальная запись Accepted History

```text
Candidate ID
Accepted At
Publication
Year
Subject Mode
Face ID
Canon Star ID
Primary Vehicle ID
Issue Mode ID
Layout Template ID
Environment Family ID
Crop Family ID
```

**Никакой одежды, причёски, света и прочих некритичных деталей.**

---

## 8. Что приложение отдаёт ChatGPT

Пример:

```text
NC R9 PRODUCTION REQUEST
Candidate ID: CAND-0042

Publication: PLAYBYTE
Year: 2077
Presentation: woman
Subject Mode: fictional_human

Face ID: F074
Canon Star: NONE
Primary Vehicle: NONE

Issue Mode: dating_relationships
Layout Template: classic_newsstand
Environment Family: resort
Crop Family: medium_full

ALL NON-CRITICAL PARAMETERS: AUTO

Instructions:
- Open and follow R9 LEAN PRODUCTION.
- Preserve every explicit value/ID above.
- Resolve all non-critical parameters through normal R9 Publication DNA,
  Issue Intelligence, layout and photo-plate pipeline.
- Run the real R9 compiler; do not mentally simulate compilation.
- Do not reinterpret or replace locked critical values because of your own preferences.
```

После этого R9 сам решает:

- одежду;
- волосы;
- makeup;
- cyberware;
- pose;
- camera details;
- lighting;
- props;
- material;
- cover copy;
- остальные editorial details.

---

## 9. Главное правило приложения

**History управляет только крупными perceptual repeats.**

Она не должна превращаться в систему, которая пытается сделать каждую следующую обложку отличной от предыдущей во всех мелочах.

Цель — не допустить ощущения:

> «опять то же лицо / та же машина / тот же layout / тот же тип выпуска / опять rooftop close-up»

а не запретить нормальное повторение чёрного платья, сатина или вечернего света.
