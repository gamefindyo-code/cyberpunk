# NC R9 Production Manager — MVP

Локальный менеджер критических параметров и history для **NC Magazine R9 LEAN PRODUCTION**.

## Что он делает

- выбирает только критические параметры обложки;
- разрешает `AUTO / RANDOM / конкретное значение`;
- создаёт `CAND-0001`, `CAND-0002` ...;
- сразу физически сохраняет Candidate в SQLite **до генерации изображения**;
- формирует короткий `NC R9 PRODUCTION REQUEST` для вставки в ChatGPT;
- ведёт `PENDING / ACCEPTED / REJECTED`;
- только `ACCEPTED` участвует в постоянном no-repeat;
- умеет Backup DB и Export Accepted History.

## Что НЕ контролируется history

Одежда, материалы, обувь, волосы, макияж, поза, gaze, lighting, cyberware details, accessories, цвет машины, мелкие props и другие некритичные детали. Они остаются `AUTO` для R9.

## Запуск из исходников на Windows

Требуется обычный Python 3.11+ с сайта python.org (Tkinter входит в стандартную Windows-установку).

```bat
py app.py
```

База хранится отдельно от программы:

`%LOCALAPPDATA%\NC_R9_Production_Manager\manager.db`

Поэтому обновление EXE не должно стирать history.

## Сборка Windows EXE

Запустите:

`build_windows.bat`

Скрипт установит PyInstaller при необходимости и соберёт:

`dist\NC_R9_Production_Manager.exe`

Это portable single-file EXE. Рабочая SQLite-база всё равно хранится в `%LOCALAPPDATA%`.

## Типичный цикл

1. Выберите критические параметры.
2. `CREATE CANDIDATE`.
3. `COPY R9 REQUEST`.
4. Вставьте текст в диалог, где загружен `R9 LEAN PRODUCTION.zip`.
5. Получите обложку.
6. В приложении нажмите `ACCEPT` или `REJECT`.
7. Следующий `AUTO/RANDOM` уже учитывает accepted history.

Важно: Candidate создаётся **до** генерации, поэтому приложение всегда знает, какие ID относятся к конкретной картинке.
