@echo off
setlocal
cd /d "%~dp0"

echo === NC R9 Production Manager: Windows build ===
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher 'py' not found. Install Python 3.11+ from python.org.
  pause
  exit /b 1
)

py -m pip show pyinstaller >nul 2>nul
if errorlevel 1 (
  echo Installing PyInstaller...
  py -m pip install --upgrade pyinstaller
  if errorlevel 1 exit /b 1
)

rmdir /s /q build 2>nul
rmdir /s /q dist 2>nul

echo Building single-file GUI EXE...
py -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name "NC_R9_Production_Manager" ^
  --add-data "data;data" ^
  app.py

if errorlevel 1 (
  echo BUILD FAILED
  pause
  exit /b 1
)

echo.
echo BUILD OK: dist\NC_R9_Production_Manager.exe
pause
