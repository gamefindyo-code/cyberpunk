from pathlib import Path
import random, tempfile
from manager_core import Catalog, ManagerDB, CandidateEngine, CandidateInput


def base(**kw):
    d=dict(publication='PLAYBYTE',year='2077',presentation='woman',subject_mode='AUTO',face_id='AUTO',canon_star_id='NONE',primary_vehicle_id='NONE',issue_mode_id='AUTO',layout_template_id='AUTO',environment_family_id='AUTO',crop_family_id='AUTO',user_note='')
    d.update(kw); return CandidateInput(**d)


def run():
    td=Path(tempfile.mkdtemp())
    db=ManagerDB(td/'manager.db')
    cat=Catalog(Path(__file__).resolve().parents[1])
    eng=CandidateEngine(db,cat,random.Random(12345))
    c1=eng.create_candidate(base())
    assert c1['candidate_id']=='CAND-0001'
    assert c1['face_id'].startswith('F')
    assert c1['issue_mode_id'] not in ('AUTO','RANDOM')
    assert c1['layout_template_id'] not in ('AUTO','RANDOM')
    db.update_status(c1['candidate_id'],'ACCEPTED')
    c2=eng.create_candidate(base())
    assert c2['face_id']!=c1['face_id'], (c1['face_id'],c2['face_id'])
    # Explicit repeat is preserved, but warned.
    explicit=base(face_id=c1['face_id'])
    warnings=eng.explicit_warnings(explicit)
    assert any(x['field']=='face_id' and x['severity']=='HARD' for x in warnings)
    c3=eng.create_candidate(explicit)
    assert c3['face_id']==c1['face_id']
    # Pending guard: auto candidate does not reuse c2/c3 face while alternatives exist.
    c4=eng.create_candidate(base())
    assert c4['face_id'] not in {c1['face_id'],c2['face_id'],c3['face_id']}
    # Automotive candidate resolves a vehicle even when input is NONE.
    auto=base(publication='NIGHT TUNER',subject_mode='AUTO',primary_vehicle_id='NONE')
    c5=eng.create_candidate(auto)
    assert c5['primary_vehicle_id']!='NONE'
    assert 'NC R9 PRODUCTION REQUEST' in c5['request_text']
    assert 'ALL NON-CRITICAL PARAMETERS: AUTO' in c5['request_text']
    # Canon + explicit face is invalid.
    canon_id=cat.canon_for_publication('PLAYBYTE')[0]['id']
    try:
        eng.create_candidate(base(face_id='F001',canon_star_id=canon_id))
    except ValueError:
        pass
    else:
        raise AssertionError('canon+face conflict should fail')
    db.close()
    print('PASS: core candidate/history tests')

if __name__=='__main__': run()
