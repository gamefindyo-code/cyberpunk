from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from manager_core import (
    APP_NAME, Catalog, ManagerDB, CandidateEngine, CandidateInput,
    DEFAULT_SETTINGS, default_user_data_dir, resource_root, display_value
)

RESERVED = {"AUTO", "RANDOM", "NONE"}


def exact_id(text: str) -> str:
    text = (text or "").strip()
    if text in RESERVED or not text:
        return text or "AUTO"
    if " | " in text:
        return text.split(" | ", 1)[0].strip()
    return text


def pretty(text: str) -> str:
    return (text or "").replace("_", " ").title()


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1320x820")
        self.minsize(1080, 680)
        self.option_add("*tearOff", False)

        self.catalog = Catalog(resource_root())
        self.db = ManagerDB()
        self.engine = CandidateEngine(self.db, self.catalog)
        self.current_candidate_id = None

        self._setup_style()
        self._build_ui()
        self._load_defaults()
        self.refresh_all()
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _setup_style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        bg = "#101318"; panel = "#171b20"; fg = "#e9eef3"; muted = "#98a3ad"; accent = "#26c6da"
        self.configure(bg=bg)
        style.configure("TFrame", background=bg)
        style.configure("Panel.TFrame", background=panel)
        style.configure("TLabel", background=bg, foreground=fg, font=("Segoe UI", 10))
        style.configure("Panel.TLabel", background=panel, foreground=fg, font=("Segoe UI", 10))
        style.configure("Section.TLabel", background=panel, foreground=accent, font=("Segoe UI Semibold", 9))
        style.configure("Title.TLabel", background=bg, foreground=fg, font=("Segoe UI Semibold", 13))
        style.configure("Muted.TLabel", background=panel, foreground=muted, font=("Segoe UI", 9))
        style.configure("TButton", font=("Segoe UI Semibold", 9), padding=7)
        style.configure("Primary.TButton", font=("Segoe UI Semibold", 10), padding=9)
        style.configure("Treeview", rowheight=26, font=("Segoe UI", 9))
        style.configure("Treeview.Heading", font=("Segoe UI Semibold", 9))
        style.configure("TNotebook", background=bg)
        style.configure("TNotebook.Tab", padding=(14, 8))

    def _build_ui(self):
        top = ttk.Frame(self, padding=(16, 12))
        top.pack(fill="x")
        ttk.Label(top, text="NC R9 PRODUCTION MANAGER", style="Title.TLabel").pack(side="left")
        self.db_label = ttk.Label(top, text=f"DB: {self.db.path}")
        self.db_label.pack(side="right")

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=12, pady=(0, 12))

        self.builder_tab = ttk.Frame(self.nb)
        self.candidates_tab = ttk.Frame(self.nb)
        self.history_tab = ttk.Frame(self.nb)
        self.settings_tab = ttk.Frame(self.nb)
        self.nb.add(self.builder_tab, text="Candidate Builder")
        self.nb.add(self.candidates_tab, text="Candidates")
        self.nb.add(self.history_tab, text="Accepted History")
        self.nb.add(self.settings_tab, text="Settings")

        self._build_builder()
        self._build_candidates()
        self._build_history()
        self._build_settings()

    def _panel(self, parent):
        return ttk.Frame(parent, style="Panel.TFrame", padding=16)

    def _build_builder(self):
        self.builder_tab.columnconfigure(0, weight=1)
        self.builder_tab.columnconfigure(1, weight=1)
        self.builder_tab.rowconfigure(0, weight=1)
        left = self._panel(self.builder_tab); left.grid(row=0, column=0, sticky="nsew", padx=(4, 7), pady=4)
        right = self._panel(self.builder_tab); right.grid(row=0, column=1, sticky="nsew", padx=(7, 4), pady=4)
        left.columnconfigure(1, weight=1); left.columnconfigure(3, weight=1)
        right.rowconfigure(6, weight=1); right.columnconfigure(0, weight=1)

        self.vars = {k: tk.StringVar() for k in [
            "publication","year","presentation","subject_mode","face_id","canon_star_id","primary_vehicle_id",
            "issue_mode_id","layout_template_id","environment_family_id","crop_family_id"
        ]}

        ttk.Label(left, text="ISSUE", style="Section.TLabel").grid(row=0,column=0,columnspan=4,sticky="w",pady=(0,8))
        self.pub_cb = self._field(left, 1, 0, "Publication", "publication", [])
        self.year_cb = self._field(left, 1, 2, "Year", "year", ["AUTO","RANDOM","2075","2076","2077"])
        self.pres_cb = self._field(left, 2, 0, "Presentation", "presentation", ["AUTO","RANDOM","woman","man","androgynous"])
        self.subject_cb = self._field(left, 2, 2, "Subject Mode", "subject_mode", [])

        ttk.Label(left, text="IDENTITY / STAR", style="Section.TLabel").grid(row=3,column=0,columnspan=4,sticky="w",pady=(18,8))
        face_vals = ["AUTO","RANDOM","NONE"] + [f"{x['id']} | age {x.get('age','?')} | {x.get('heritage_reference','')}" for x in self.catalog.faces]
        self.face_cb = self._field(left, 4, 0, "Face ID", "face_id", face_vals)
        canon_vals = ["NONE","AUTO","RANDOM"] + [f"{x['id']} | {x['name']}" for x in self.catalog.canon_stars]
        self.canon_cb = self._field(left, 4, 2, "Canon Star", "canon_star_id", canon_vals)
        veh_vals = ["NONE","AUTO","RANDOM"] + [x["id"] for x in self.catalog.vehicles]
        self.vehicle_cb = self._field(left, 5, 0, "Primary Vehicle", "primary_vehicle_id", veh_vals, colspan=3)

        ttk.Label(left, text="EDITORIAL / COMPOSITION", style="Section.TLabel").grid(row=6,column=0,columnspan=4,sticky="w",pady=(18,8))
        self.issue_cb = self._field(left, 7, 0, "Issue Mode", "issue_mode_id", [])
        self.layout_cb = self._field(left, 7, 2, "Layout Template", "layout_template_id", [])
        env_vals = ["AUTO","RANDOM"] + [f"{x['id']} | {x['label']}" for x in self.catalog.environment_families]
        crop_vals = ["AUTO","RANDOM"] + [f"{x['id']} | {x['label']}" for x in self.catalog.crop_families]
        self.env_cb = self._field(left, 8, 0, "Environment Family", "environment_family_id", env_vals)
        self.crop_cb = self._field(left, 8, 2, "Crop Family", "crop_family_id", crop_vals)

        ttk.Label(left, text="OPTIONAL NOTES", style="Section.TLabel").grid(row=9,column=0,columnspan=4,sticky="w",pady=(18,8))
        self.note = tk.Text(left, height=5, wrap="word", bg="#20252b", fg="#eef2f5", insertbackground="white", relief="flat", padx=8, pady=8)
        self.note.grid(row=10,column=0,columnspan=4,sticky="nsew")

        buttons = ttk.Frame(left, style="Panel.TFrame"); buttons.grid(row=11,column=0,columnspan=4,sticky="ew",pady=(14,0))
        ttk.Button(buttons,text="🎲 RANDOMIZE AUTO/RANDOM",command=self.randomize_modes).pack(side="left")
        ttk.Button(buttons,text="RESET TO AUTO",command=self._load_defaults).pack(side="left",padx=8)
        ttk.Button(buttons,text="CREATE CANDIDATE",style="Primary.TButton",command=self.create_candidate).pack(side="right")

        # Right summary/detail.
        ttk.Label(right,text="LIVE SUMMARY / CANDIDATE",style="Section.TLabel").grid(row=0,column=0,sticky="w")
        self.next_id_var = tk.StringVar(value="Next: CAND-0001")
        ttk.Label(right,textvariable=self.next_id_var,style="Muted.TLabel").grid(row=1,column=0,sticky="w",pady=(5,8))
        self.summary = tk.Text(right,height=11,wrap="word",state="disabled",bg="#20252b",fg="#e9eef3",relief="flat",padx=10,pady=10)
        self.summary.grid(row=2,column=0,sticky="ew")
        ttk.Label(right,text="HISTORY CHECK",style="Section.TLabel").grid(row=3,column=0,sticky="w",pady=(14,6))
        self.warnings = tk.Text(right,height=6,wrap="word",state="disabled",bg="#20252b",fg="#ffcf66",relief="flat",padx=10,pady=8)
        self.warnings.grid(row=4,column=0,sticky="ew")
        ttk.Label(right,text="R9 REQUEST",style="Section.TLabel").grid(row=5,column=0,sticky="w",pady=(14,6))
        self.request = tk.Text(right,wrap="word",state="disabled",bg="#111418",fg="#cfd8df",relief="flat",padx=10,pady=10,font=("Consolas",9))
        self.request.grid(row=6,column=0,sticky="nsew")
        act = ttk.Frame(right,style="Panel.TFrame"); act.grid(row=7,column=0,sticky="ew",pady=(10,0))
        ttk.Button(act,text="COPY R9 REQUEST",command=self.copy_request).pack(side="left")
        self.accept_btn=ttk.Button(act,text="✓ ACCEPT",command=lambda:self.set_current_status("ACCEPTED")); self.accept_btn.pack(side="right")
        self.reject_btn=ttk.Button(act,text="✕ REJECT",command=lambda:self.set_current_status("REJECTED")); self.reject_btn.pack(side="right",padx=8)
        self.pending_btn=ttk.Button(act,text="↶ PENDING",command=lambda:self.set_current_status("PENDING")); self.pending_btn.pack(side="right")
        self.duplicate_btn=ttk.Button(act,text="DUPLICATE",command=self.duplicate_current); self.duplicate_btn.pack(side="right",padx=8)

        self.pub_cb.bind("<<ComboboxSelected>>", self.on_publication_changed)
        for cb in [self.year_cb,self.pres_cb,self.subject_cb,self.face_cb,self.canon_cb,self.vehicle_cb,self.issue_cb,self.layout_cb,self.env_cb,self.crop_cb]:
            cb.bind("<<ComboboxSelected>>", lambda e:self.update_live_summary())
        self.note.bind("<KeyRelease>", lambda e:self.update_live_summary())

    def _field(self, parent, row, col, label, key, values, colspan=1):
        frame=ttk.Frame(parent,style="Panel.TFrame")
        frame.grid(row=row,column=col,columnspan=colspan,sticky="ew",padx=(0,10) if col<2 else 0,pady=5)
        frame.columnconfigure(0,weight=1)
        ttk.Label(frame,text=label,style="Muted.TLabel").grid(row=0,column=0,sticky="w")
        cb=ttk.Combobox(frame,textvariable=self.vars[key],values=values,state="readonly",width=28)
        cb.grid(row=1,column=0,sticky="ew",pady=(3,0))
        return cb

    def _build_candidates(self):
        top=ttk.Frame(self.candidates_tab,padding=8); top.pack(fill="x")
        ttk.Label(top,text="Status").pack(side="left")
        self.cand_status=tk.StringVar(value="ALL")
        cb=ttk.Combobox(top,textvariable=self.cand_status,values=["ALL","PENDING","ACCEPTED","REJECTED"],state="readonly",width=12); cb.pack(side="left",padx=6)
        ttk.Label(top,text="Publication").pack(side="left",padx=(12,0))
        self.cand_pub=tk.StringVar(value="ALL")
        cb2=ttk.Combobox(top,textvariable=self.cand_pub,values=["ALL"]+self.catalog.publications,state="readonly",width=20); cb2.pack(side="left",padx=6)
        ttk.Button(top,text="Refresh",command=self.refresh_candidates).pack(side="left",padx=6)
        ttk.Button(top,text="Open Selected",command=self.open_selected_candidate).pack(side="right")
        cb.bind("<<ComboboxSelected>>",lambda e:self.refresh_candidates()); cb2.bind("<<ComboboxSelected>>",lambda e:self.refresh_candidates())

        cols=("id","status","created","publication","year","face","canon","vehicle","issue","layout")
        self.cand_tree=ttk.Treeview(self.candidates_tab,columns=cols,show="headings",selectmode="browse")
        heads={"id":"Candidate","status":"Status","created":"Created","publication":"Publication","year":"Year","face":"Face","canon":"Canon","vehicle":"Vehicle","issue":"Issue Mode","layout":"Layout"}
        widths={"id":105,"status":90,"created":150,"publication":125,"year":60,"face":70,"canon":90,"vehicle":170,"issue":150,"layout":160}
        for c in cols:
            self.cand_tree.heading(c,text=heads[c]); self.cand_tree.column(c,width=widths[c],anchor="w")
        self.cand_tree.pack(fill="both",expand=True,padx=8,pady=(0,8))
        self.cand_tree.bind("<Double-1>",lambda e:self.open_selected_candidate())

    def _build_history(self):
        top=ttk.Frame(self.history_tab,padding=8); top.pack(fill="x")
        self.hist_pub=tk.StringVar(value="ALL")
        ttk.Label(top,text="Publication").pack(side="left")
        cb=ttk.Combobox(top,textvariable=self.hist_pub,values=["ALL"]+self.catalog.publications,state="readonly",width=20); cb.pack(side="left",padx=6)
        cb.bind("<<ComboboxSelected>>",lambda e:self.refresh_history())
        ttk.Button(top,text="Export CSV",command=self.export_history).pack(side="right")
        ttk.Button(top,text="Backup DB",command=self.backup_db).pack(side="right",padx=6)
        ttk.Button(top,text="Restore DB",command=self.restore_db).pack(side="right",padx=6)

        cols=("id","accepted","publication","year","face","canon","vehicle","issue","layout","environment","crop")
        self.hist_tree=ttk.Treeview(self.history_tab,columns=cols,show="headings")
        names={"id":"Candidate","accepted":"Accepted","publication":"Publication","year":"Year","face":"Face","canon":"Canon","vehicle":"Vehicle","issue":"Issue Mode","layout":"Layout","environment":"Environment","crop":"Crop"}
        widths={"id":105,"accepted":155,"publication":120,"year":60,"face":65,"canon":85,"vehicle":155,"issue":145,"layout":150,"environment":120,"crop":110}
        for c in cols:
            self.hist_tree.heading(c,text=names[c]); self.hist_tree.column(c,width=widths[c],anchor="w")
        self.hist_tree.pack(fill="both",expand=True,padx=8,pady=(0,8))

    def _build_settings(self):
        wrap=self._panel(self.settings_tab); wrap.pack(fill="both",expand=True,padx=8,pady=8)
        ttk.Label(wrap,text="NO-REPEAT WINDOWS",style="Section.TLabel").grid(row=0,column=0,columnspan=4,sticky="w",pady=(0,10))
        self.setting_vars={}
        setting_rows=[
            ("Face ID","history.face_id.window"),("Canon Star","history.canon_star_id.window"),("Primary Vehicle","history.primary_vehicle_id.window"),
            ("Subject Mode","history.subject_mode.window"),("Issue Mode","history.issue_mode_id.window"),("Layout","history.layout_template_id.window"),
            ("Environment","history.environment_family_id.window"),("Crop","history.crop_family_id.window")
        ]
        for i,(label,key) in enumerate(setting_rows,1):
            ttk.Label(wrap,text=label,style="Panel.TLabel").grid(row=i,column=0,sticky="w",pady=4)
            v=tk.IntVar(value=int(self.engine.setting(key))); self.setting_vars[key]=v
            ttk.Spinbox(wrap,from_=0,to=50,textvariable=v,width=8).grid(row=i,column=1,sticky="w",padx=8)
        ttk.Label(wrap,text="PENDING BATCH GUARD",style="Section.TLabel").grid(row=0,column=2,columnspan=2,sticky="w",padx=(40,0),pady=(0,10))
        self.guard_vars={}
        guards=[("Face ID","pending_guard.face_id"),("Canon Star","pending_guard.canon_star_id"),("Primary Vehicle","pending_guard.primary_vehicle_id"),("Layout","pending_guard.layout_template_id")]
        for i,(label,key) in enumerate(guards,1):
            v=tk.BooleanVar(value=bool(self.engine.setting(key))); self.guard_vars[key]=v
            ttk.Checkbutton(wrap,text=label,variable=v).grid(row=i,column=2,columnspan=2,sticky="w",padx=(40,0),pady=4)
        ttk.Button(wrap,text="SAVE SETTINGS",style="Primary.TButton",command=self.save_settings).grid(row=10,column=0,columnspan=2,sticky="w",pady=(20,0))
        info=("History ограничивает только крупные perceptual repeats. Одежда, волосы, макияж, поза, свет, материалы, cyberware details и мелкие props не участвуют в no-repeat.")
        ttk.Label(wrap,text=info,style="Muted.TLabel",wraplength=760,justify="left").grid(row=11,column=0,columnspan=4,sticky="w",pady=(20,0))

    def _load_defaults(self):
        self.vars["publication"].set("PLAYBYTE")
        self.vars["year"].set("2077")
        self.vars["presentation"].set("AUTO")
        self.vars["subject_mode"].set("AUTO")
        self.vars["face_id"].set("AUTO")
        self.vars["canon_star_id"].set("NONE")
        self.vars["primary_vehicle_id"].set("NONE")
        self.vars["issue_mode_id"].set("AUTO")
        self.vars["layout_template_id"].set("AUTO")
        self.vars["environment_family_id"].set("AUTO")
        self.vars["crop_family_id"].set("AUTO")
        if hasattr(self,"note"):
            self.note.delete("1.0","end")
        if hasattr(self,"pub_cb"):
            self.pub_cb["values"]=self.catalog.publications
            self.on_publication_changed()
        self.current_candidate_id=None
        if hasattr(self,"request"): self._set_text(self.request,"")
        self.update_live_summary()

    def on_publication_changed(self, event=None):
        pub=self.vars["publication"].get() or "PLAYBYTE"
        self.subject_cb["values"]=["AUTO","RANDOM"]+[x["id"] for x in self.catalog.subject_modes(pub)]
        self.issue_cb["values"]=["AUTO","RANDOM"]+[f"{x['id']} | {x['label']}" for x in self.catalog.issue_modes(pub)]
        self.layout_cb["values"]=["AUTO","RANDOM"]+[x["id"] for x in self.catalog.layouts(pub)]
        for key,cb in [("subject_mode",self.subject_cb),("issue_mode_id",self.issue_cb),("layout_template_id",self.layout_cb)]:
            cur=exact_id(self.vars[key].get())
            valid=[exact_id(x) for x in cb["values"]]
            if cur not in valid: self.vars[key].set("AUTO")
        if self.catalog.is_automotive(pub) and self.vars["primary_vehicle_id"].get()=="NONE":
            self.vars["primary_vehicle_id"].set("AUTO")
        self.update_live_summary()

    def randomize_modes(self):
        # RANDOM means "choose a concrete admissible value at Candidate creation".
        for key in ["presentation","subject_mode","face_id","issue_mode_id","layout_template_id","environment_family_id","crop_family_id"]:
            if self.vars[key].get() in {"AUTO","RANDOM"}: self.vars[key].set("RANDOM")
        if self.vars["canon_star_id"].get()=="AUTO": self.vars["canon_star_id"].set("RANDOM")
        if self.vars["primary_vehicle_id"].get()=="AUTO": self.vars["primary_vehicle_id"].set("RANDOM")
        self.update_live_summary()

    def current_input(self):
        return CandidateInput(
            publication=self.vars["publication"].get(), year=exact_id(self.vars["year"].get()), presentation=exact_id(self.vars["presentation"].get()),
            subject_mode=exact_id(self.vars["subject_mode"].get()), face_id=exact_id(self.vars["face_id"].get()), canon_star_id=exact_id(self.vars["canon_star_id"].get()),
            primary_vehicle_id=exact_id(self.vars["primary_vehicle_id"].get()), issue_mode_id=exact_id(self.vars["issue_mode_id"].get()), layout_template_id=exact_id(self.vars["layout_template_id"].get()),
            environment_family_id=exact_id(self.vars["environment_family_id"].get()), crop_family_id=exact_id(self.vars["crop_family_id"].get()), user_note=self.note.get("1.0","end").strip()
        )

    def update_live_summary(self):
        if not hasattr(self,"summary"): return
        _,next_id=self.db.next_candidate_id()
        self.next_id_var.set(f"Next: {next_id}")
        inp=self.current_input()
        lines=[
            f"Publication: {inp.publication} / {inp.year}", f"Presentation: {inp.presentation}", f"Subject Mode: {inp.subject_mode}",
            f"Face ID: {inp.face_id}", f"Canon Star: {inp.canon_star_id}", f"Primary Vehicle: {inp.primary_vehicle_id}",
            f"Issue Mode: {inp.issue_mode_id}", f"Layout: {inp.layout_template_id}", f"Environment: {inp.environment_family_id}", f"Crop: {inp.crop_family_id}",
        ]
        self._set_text(self.summary,"\n".join(lines))
        warns=self.engine.explicit_warnings(inp)
        if warns:
            text="\n".join(("⚠ " if x["severity"] in {"HARD","PENDING"} else "• ")+x["message"] for x in warns)
        else:
            text="✓ Нет конфликтов для явно выбранных критических значений. AUTO/RANDOM будут проверены при создании Candidate."
        self._set_text(self.warnings,text)

    def create_candidate(self):
        inp=self.current_input()
        warns=self.engine.explicit_warnings(inp)
        hard=[x for x in warns if x["severity"]=="HARD"]
        if hard:
            msg="Обнаружен HARD repeat для явно выбранного значения:\n\n"+"\n".join(x["message"] for x in hard)+"\n\nИспользовать всё равно?"
            if not messagebox.askyesno("History warning",msg,parent=self): return
        try:
            rec=self.engine.create_candidate(inp)
        except Exception as e:
            messagebox.showerror("Candidate error",str(e),parent=self); return
        self.show_candidate(rec["candidate_id"])
        self.refresh_all()
        messagebox.showinfo("Candidate created",f"Создан {rec['candidate_id']} и сохранён в локальной базе как PENDING.",parent=self)

    def show_candidate(self,cid):
        rec=self.db.get_candidate(cid)
        if not rec: return
        self.current_candidate_id=cid
        lines=[
            f"{rec['candidate_id']}   STATUS: {rec['status']}","",
            f"{rec['publication']} / {rec['year']}", f"Presentation: {display_value(rec['presentation'])}", f"Subject Mode: {display_value(rec['subject_mode'])}",
            f"Face ID: {display_value(rec['face_id'])}", f"Canon Star: {display_value(rec['canon_star_id'])}", f"Primary Vehicle: {display_value(rec['primary_vehicle_id'])}",
            f"Issue Mode: {display_value(rec['issue_mode_id'])}", f"Layout: {display_value(rec['layout_template_id'])}", f"Environment: {display_value(rec['environment_family_id'])}", f"Crop: {display_value(rec['crop_family_id'])}",
        ]
        self._set_text(self.summary,"\n".join(lines)); self._set_text(self.request,rec["request_text"])
        self._set_text(self.warnings,"Candidate физически сохранён в DB. ACCEPT добавит его critical values в постоянную history; REJECT не занимает rotation.")

    def copy_request(self):
        if not self.current_candidate_id:
            messagebox.showinfo("No candidate","Сначала создайте или откройте Candidate.",parent=self); return
        rec=self.db.get_candidate(self.current_candidate_id)
        if not rec: return
        self.clipboard_clear(); self.clipboard_append(rec["request_text"]); self.update()
        messagebox.showinfo("Copied",f"R9 Request для {self.current_candidate_id} скопирован.",parent=self)

    def set_current_status(self,status):
        if not self.current_candidate_id:
            messagebox.showinfo("No candidate","Сначала создайте или откройте Candidate.",parent=self); return
        rec=self.db.get_candidate(self.current_candidate_id)
        if not rec: return
        verb="принять" if status=="ACCEPTED" else "отклонить"
        if not messagebox.askyesno("Confirm",f"{verb.capitalize()} {self.current_candidate_id}?",parent=self): return
        self.db.update_status(self.current_candidate_id,status)
        self.show_candidate(self.current_candidate_id); self.refresh_all()

    def duplicate_current(self):
        if not self.current_candidate_id: return
        try: rec=self.engine.duplicate_as_new(self.current_candidate_id)
        except Exception as e: messagebox.showerror("Duplicate error",str(e),parent=self); return
        self.show_candidate(rec["candidate_id"]); self.refresh_all()

    def refresh_candidates(self):
        for x in self.cand_tree.get_children(): self.cand_tree.delete(x)
        rows=self.db.list_candidates(self.cand_status.get(),self.cand_pub.get())
        for r in rows:
            self.cand_tree.insert("","end",iid=r["candidate_id"],values=(r["candidate_id"],r["status"],r["created_at"],r["publication"],r["year"],display_value(r["face_id"]),display_value(r["canon_star_id"]),display_value(r["primary_vehicle_id"]),display_value(r["issue_mode_id"]),display_value(r["layout_template_id"])))

    def open_selected_candidate(self):
        sel=self.cand_tree.selection()
        if not sel: return
        self.show_candidate(sel[0]); self.nb.select(self.builder_tab)

    def refresh_history(self):
        for x in self.hist_tree.get_children(): self.hist_tree.delete(x)
        pub=self.hist_pub.get()
        rows=self.db.list_candidates("ACCEPTED",None if pub=="ALL" else pub)
        for r in rows:
            self.hist_tree.insert("","end",values=(r["candidate_id"],r["accepted_at"],r["publication"],r["year"],display_value(r["face_id"]),display_value(r["canon_star_id"]),display_value(r["primary_vehicle_id"]),display_value(r["issue_mode_id"]),display_value(r["layout_template_id"]),display_value(r["environment_family_id"]),display_value(r["crop_family_id"])))

    def refresh_all(self):
        self.refresh_candidates(); self.refresh_history(); self.update_live_summary()

    def save_settings(self):
        for key,var in self.setting_vars.items(): self.db.set_setting(key,int(var.get()))
        for key,var in self.guard_vars.items(): self.db.set_setting(key,bool(var.get()))
        messagebox.showinfo("Settings","Настройки history сохранены.",parent=self)
        self.update_live_summary()

    def backup_db(self):
        path=filedialog.asksaveasfilename(title="Backup database",defaultextension=".db",filetypes=[("SQLite database","*.db"),("All files","*.*")],initialfile="NC_R9_Manager_backup.db")
        if not path: return
        try:self.db.backup(Path(path)); messagebox.showinfo("Backup",f"Backup сохранён:\n{path}",parent=self)
        except Exception as e:messagebox.showerror("Backup error",str(e),parent=self)

    def restore_db(self):
        path=filedialog.askopenfilename(title="Restore database",filetypes=[("SQLite database","*.db"),("All files","*.*")])
        if not path:return
        if not messagebox.askyesno("Restore", "Текущая локальная база будет заменена выбранным backup. Продолжить?", parent=self): return
        try:
            target=self.db.path
            self.db.close()
            shutil.copy2(path,target)
            self.db=ManagerDB(target); self.engine=CandidateEngine(self.db,self.catalog)
            self.db_label.configure(text=f"DB: {self.db.path}")
            self.refresh_all(); messagebox.showinfo("Restore","Backup восстановлен.",parent=self)
        except Exception as e:
            messagebox.showerror("Restore error",str(e),parent=self)

    def export_history(self):
        path=filedialog.asksaveasfilename(title="Export accepted history",defaultextension=".csv",filetypes=[("CSV","*.csv")],initialfile="NC_R9_Accepted_History.csv")
        if not path:return
        try:self.db.export_accepted_csv(Path(path)); messagebox.showinfo("Export",f"History exported:\n{path}",parent=self)
        except Exception as e:messagebox.showerror("Export error",str(e),parent=self)

    @staticmethod
    def _set_text(widget,text):
        widget.configure(state="normal"); widget.delete("1.0","end"); widget.insert("1.0",text); widget.configure(state="disabled")

    def on_close(self):
        try:self.db.close()
        finally:self.destroy()


def main():
    App().mainloop()


if __name__ == "__main__":
    main()
