# MVP Validation Report

Validated in the build environment:

- `app.py` syntax: PASS
- `manager_core.py` syntax: PASS
- Tkinter import: PASS (Tk 8.6)
- SQLite candidate creation: PASS
- Candidate IDs: PASS
- PENDING / ACCEPTED / REJECTED state model: PASS
- Explicit Face ID repeat preserved + warning: PASS
- AUTO Face ID no-repeat stress: 30 accepted PLAYBYTE covers, no repeat inside preceding 12: PASS
- AUTO vehicle no-repeat stress: 20 accepted NIGHT TUNER covers, no repeat inside preceding 6 vehicle covers: PASS
- Automotive candidate resolves a concrete primary vehicle before request creation: PASS
- Canon Star + explicit fictional Face ID conflict: blocked: PASS
- R9 Request contains concrete critical values + `ALL NON-CRITICAL PARAMETERS: AUTO`: PASS

The Windows `.exe` itself is **not** compiled in this Linux environment. `build_windows.bat` is included to build the single-file EXE on Windows with PyInstaller.
