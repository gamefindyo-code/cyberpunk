# Сборка Windows EXE через GitHub Actions

Workflow: `.github/workflows/build-windows-exe.yml`.

После загрузки проекта в GitHub:

1. Открой вкладку **Actions**.
2. Выбери **Build Windows EXE**.
3. Нажми **Run workflow**.
4. После завершения скачай artifact **NC_R9_Production_Manager_Windows**.
5. Внутри будет `NC_R9_Production_Manager.exe`.

Workflow также запускается автоматически при push в `main`.

Он выполняет тесты перед сборкой, собирает single-file GUI EXE через PyInstaller на `windows-latest` и проверяет, что бинарник действительно создан.
